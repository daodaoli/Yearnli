#include "config.h"

TPCCTxnType                     g_tpcc_txn_type = TPCC_ALL;
