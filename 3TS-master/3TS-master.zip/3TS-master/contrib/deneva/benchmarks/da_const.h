#pragma once

enum {
    X,
    Y,
    Z,
    };

enum{
    ID,
    VALUE
};
