
/*#include"da_query_queue.h"
#include"da_query.h"


bool DAQueryQueue::push(DAQuery query)
{
    if(!queue.push(query))
        return false;
    else
        return true;
}
int DAQueryQueue::pop();
int DAQueryQueue::is_full();
int DAQueryQueue::is_empty();
*/
