g++ $1 -lpthread -lgtest -std=c++11 -lconfig++  
./a.out 
rm ./a.out 
